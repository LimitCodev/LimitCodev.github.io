
  # Portfolio Design Mockup

  This is a code bundle for Portfolio Design Mockup. The original project is available at https://www.figma.com/design/AiGsovpSdsOAadmmCDHdxa/Portfolio-Design-Mockup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  